##########################################################
# Surface data for July 2002 from the ECMWF 40 Years Re-Analysis, 
# daily fields. (ECMWF ERA-40)
###########################################################



############################################
library("ncdf")
# read a netcdf file 


fid<- open.ncdf("ECMWF_ERA-40_subset.nc",write=FALSE)
print(fid)

    # reading the coordinates values
    lon <- get.var.ncdf(fid, "longitude")
    nlon <- dim(lon)
     
    lat <- get.var.ncdf(fid, "latitude")
    nlat <- dim(lat)

# confirm dimension of the data
print(c(nlon, nlat)) 

# read the time variable
t <- get.var.ncdf(fid, "time")
tunits <- att.get.ncdf(fid, "time", "units")
tunits # The object tunits has two components hasatt (a logical variable), 
       # and tunits$value, the actual "time since" string.
dim(t)


# extract variable: '2 metre temperature'
tmp.array <- get.var.ncdf(fid, 'p2t')
dim(tmp.array)
          dlname <- att.get.ncdf(fid, 'p2t', "long_name")
          dunits <- att.get.ncdf(fid, 'p2t', "units")
          dunits$value
          # missng values
          fillvalue <- att.get.ncdf(fid, 'p2t', "_FillValue")
          fillvalue$value

close.ncdf(ncin)

#tmp.array[tmp.array == fillvalue$value] <- NA
#max(tmp.array,na.rm = TRUE)


#If you have a look at 'lat' you see that the values are in reverse (which image will frown upon) so let's reverse them:
lat <- rev(lat)
tmp.array <- tmp.array[,ncol(tmp.array):1, ] #lat being dim 2 in this file

lon <- lon -180


image(lon,lat,tmp.array[,,1])

#And then let's superimpose a world map:
library(maptools)
data(wrld_simpl)
plot(wrld_simpl,add=TRUE)


##################################################################
# Data interpolation

## cargar las extensiones ("paquetes") con funcionalidad requerida:

library(gstat)
library(rgdal)

#######################################################
# 1. leer los datos y convertir a promedios mensuales #
#######################################################

## leer los datos (busque el archivo "INAMHI.csv")

INAMHI <- read.csv(file.choose())

## seleccionar las coordenadas y convertir en un objeto de mapa
coordinates(INAMHI) <- c("x", "y")
proj4string(INAMHI) <- "+proj=utm +zone=17 +south +ellps=WGS72 +units=m +no_defs"

## OPCIONAL: visualizar

spplot(INAMHI, scales=list(draw=TRUE), zcol="ene")

## calcular el logaritmo:
#INAMHI@data <- log(INAMHI@data + 0.01)

########################################################
# 2. leer los mapas TRMM y comparar con las estaciones #
########################################################

## leer los mapas
## referencia: Nesbitt, S. W., and A. M. Anders, 2009.
## Very high resolution precipitation climatologies from the
## Tropical Rainfall Measuring Mission precipitation radar.
## Geophys. Res. Lett., 36, L15815,

##TRMM

DJF <- readGDAL(file.choose()) # Ecuador_DJF.tif
MAM <- readGDAL(file.choose()) # Ecuador_MAM.tif
JJA <- readGDAL(file.choose()) # Ecuador_JJA.tif                  
SON <- readGDAL(file.choose()) # Ecuador_SON.tif


## OPCIONAL: explorar y visualizar
summary(DJF)
spplot(DJF, scales=list(draw = TRUE))

## transformar los TRMM de grados a UTM17
## OJO: se generara un "warning", debido a la conversion de grid a point pero no importa
DJF <- as(DJF,"SpatialPointsDataFrame")


DJF <- spTransform(DJF, CRS(proj4string(INAMHI)))
MAM <- spTransform(MAM, CRS(proj4string(INAMHI)))
JJA <- spTransform(JJA, CRS(proj4string(INAMHI)))
SON <- spTransform(SON, CRS(proj4string(INAMHI)))

## obtener los valores TRMM en los puntos de las estaciones y añadir a nuestra tabla 

for(mapa in c(DJF, MAM, JJA, SON)) {
  pointsTRMM <- idw(band1 ~ 1, mapa, INAMHI, nmax = 1)
  #  INAMHI@data <- cbind(INAMHI@data, log(pointsTRMM$var1.pred + 0.01))
  INAMHI@data <- cbind(INAMHI@data, pointsTRMM$var1.pred) 
}
names(INAMHI@data)[13:16] <- c("DJF", "MAM", "JJA", "SON")

## OPCIONAL: explorar nuestros datos

summary(INAMHI)

## OPCIONAL: comparar los datos:

plot(INAMHI$ene, INAMHI$DJF)
cor(INAMHI$ene, INAMHI$DJF)


####################################################
# 3. interpolation using co-kriging 
# cross- validation
####################################################

## check names of TRMM maps
names(DJF) <- "DJF"
names(MAM) <- "MAM"
names(JJA) <- "JJA"
names(SON) <- "SON"

## choose one month.
## common models are Exp, Gau, y Sph. If one doesnt work try another on

formula <- formula(feb ~ DJF)
exp_var <- variogram(formula, data =  INAMHI)
## look at the semivariogram and estimate model parameters
plot(exp_var)

## build up a model:
theoretic_model <- vgm(5000, "Sph", 150000, 25000) ## psill range nugget

## adjust:
fitted_model    <- fit.variogram(exp_var, theoretic_model, fit.method=1)

## check the adjustment:
plot(exp_var, fitted_model)

## kriging (OJO: si se usa otros meses que no sean dic, ene, feb, cambiar el mapa de covariable (DJF)
mapa <- krige(formula, INAMHI, DJF, model = fitted_model)

## analizar y plotear:
summary(mapa)
spplot(mapa["var1.pred"], scales = list(draw = TRUE))

## validación cruzada:
crossval <- krige.cv(formula, INAMHI, model = fitted_model)
as.data.frame(crossval)[1:5,]
summary(as.data.frame(crossval))