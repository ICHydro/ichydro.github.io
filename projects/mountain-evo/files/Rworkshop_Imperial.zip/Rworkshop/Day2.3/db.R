library(dplyr)
library(nycflights13)
data(flights)
View(flights)
names(flights)

saveRDS(flights,file = "~/flights.rds") # 5.7 MB
save(flights,file = "~/flights.rda") # 5.7 MB

my_db <- src_sqlite("my_db.sqlite3", create = T)

flights_sqlite <- copy_to(my_db, flights, temporary = FALSE,
                          indexes = list(c("year", "month", "day"),
                                         "carrier", "tailnum"))

x <- flights[, c("year", "month", "day", "dep_delay", "arr_delay")]
y <- select(flights_sqlite, year:day, dep_delay, arr_delay)

x <- flights[which(flights$dep_delay > 240), ]
y <- filter(flights_sqlite, dep_delay > 240)

x <- flights[order(c("year", "month", "day")),]
y <- arrange(flights_sqlite, year, month, day)

x <- cbind(flights, speed = flights$air_time / flights$distance)
y <- mutate(flights_sqlite, speed = air_time / distance)

x <- mean(flights$dep_time, na.rm = TRUE)
y <- summarise(flights_sqlite, delay = mean(dep_time))

str(x)
str(y)
yy <- collect(y)
all(x == yy, na.rm = T)
