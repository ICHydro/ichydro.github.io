
#########################################################
# Surface data for July 2002 from the ECMWF 40 Years Re-Analysis, 
# daily fields. (ECMWF ERA-40)
###########################################################
 # is the time correct?

library(raster)
library(sp)
library(rgdal)

DEM <- raster("WalesDTMterra50.tif")
plot(DEM, main="Digital Elevation Model for Wales")

str(DEM)

slotNames(DEM)

cellStats(DEM, range)

hist(DEM)

hist(DEM, maxpixels=DEM@ncols*DEM@nrows)

############################################
library("ncdf")
# read a netcdf file 


fid<- open.ncdf("ECMWF_ERA-40_subset.nc",write=FALSE)
print(fid)

    # reading the coordinates values
    lon <- get.var.ncdf(fid, "longitude")
    nlon <- dim(lon)
     
    lat <- get.var.ncdf(fid, "latitude")
    nlat <- dim(lat)

# confirm dimension of the data
print(c(nlon, nlat)) 

# read the time variable
t <- get.var.ncdf(fid, "time")
tunits <- att.get.ncdf(fid, "time", "units")
tunits # The object tunits has two components hasatt (a logical variable), 
       # and tunits$value, the actual "time since" string.
dim(t)


# extract variable: '2 metre temperature'
tmp.array <- get.var.ncdf(fid, 'p2t')
dim(tmp.array)
          dlname <- att.get.ncdf(fid, 'p2t', "long_name")
          dunits <- att.get.ncdf(fid, 'p2t', "units")
          dunits$value
          # missng values
          fillvalue <- att.get.ncdf(fid, 'p2t', "_FillValue")
          fillvalue$value

close.ncdf(ncin)

#tmp.array[tmp.array == fillvalue$value] <- NA
#max(tmp.array,na.rm = TRUE)


#If you have a look at 'lat' you see that the values are in reverse (which image will frown upon) so let's reverse them:
lat <- rev(lat)
tmp.array <- tmp.array[,ncol(tmp.array):1, ] #lat being dim 2 in this file



lon <- lon -180

image(lon,lat,tmp.array[,,1])

#And then let's superimpose a world map:
library(maptools)
data(wrld_simpl)
plot(wrld_simpl,add=TRUE)


##############################################################

# Creating a netCDF file from within R

# Topographic Information on Auckland's Maunga Whau Volcano on a 10m by 10m grid
data(volcano)

# put the data in a handy form 
z = volcano         # matrix of elevations
x = 10* (1:nrow(z))   # meter spacing (S to N)
y = 10* (1:ncol(z))   # meter spacing (E to W)

# define the netcdf coordinate variables -- note these have values!

dim1 = dim.def.ncdf( "EW","meters", as.double(x))
dim2 = dim.def.ncdf( "SN","meters", as.double(y))

# define the EMPTY (elevation) netcdf variable
varz = var.def.ncdf("Elevation","meters", list(dim1,dim2), -1, 
                    longname="The Classic R New Zealand Volcano")

# associate the netcdf variable with a netcdf file   
# put the variable into the file, and
# close

nc.ex = create.ncdf( "example.nc", varz )
put.var.ncdf(nc.ex, varz, z)
close.ncdf(nc.ex)

# clear all
rm(list=ls(all=TRUE))

fid<- open.ncdf("example.nc",write=FALSE)
print(fid)



