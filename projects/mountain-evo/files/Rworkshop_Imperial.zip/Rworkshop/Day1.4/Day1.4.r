#######################################################
# Basic Data Analysis                                 #
# Imperial College London, 28 September 2015          #
# R workshop                                          #
#######################################################

# A) Date
# create a date:
dt1 <- as.Date("2012-07-21")
dt1
#non-standard formats must be specified:
dt2 <- as.Date("04/20/2011", format = "%m/%d/%Y")
dt2
dt3 <- as.Date("October 6, 2010", format = "%B %d, %Y")
dt3

# list of format symbols:
?strptime

# calculations with Dates
dt1 - dt2
difftime(dt1, dt2, units = "weeks")

#see the internal integer representation
unclass(dt1)

# B) POSIXct
# create some POSIXct objects:
tm1 <- as.POSIXct("2013-07-24 23:55:26")
tm1
tm2 <- as.POSIXct("25072013 08:32:07", format = "%d%m%Y %H:%M:%S")
tm2
# specify the time zone:
tm3 <- as.POSIXct("2010-12-01 11:42:03", tz = "GMT")
tm3

tm2-tm1

# C) POSIXlt
tm1.lt <- as.POSIXlt("2013-07-24 23:55:58")
tm1.lt

# extract components of a time object:
tm1.lt$sec
tm1.lt$wday

# truncate or round off the time:
trunc(tm1.lt, "days")
trunc(tm1.lt, "mins")

#######################################################################################

# Global Temperature Deviation from 1856-1997
globtemp <-  ts(scan("globtemp.dat"), start=1856)
plot(globtemp)


##########################################################################
# Daily Closing Prices of Major European Stock Indices, 1991-1998
library(zoo)

data(EuStockMarkets)

ST.days <- seq(from=as.Date("1991-1-1",format="%Y-%m-%d"),by="days",
               length.out=dim(EuStockMarkets)[1])

ST.zoo <- zoo(EuStockMarkets, ST.days)
ST.zoo[1:10]
plot(ST.zoo)

# Calculate 10-day rolling mean, quickly:
plot(ST.zoo[,4])
ST.smooth <- rollmean(x = ST.zoo[,4],    # FTSE index
                        k = 60,          # width of the rolling window
                        fill = NA)       # Pads head and/or tail with NA
lines(ST.smooth, col = "red")

####################################################################################
# Linear Regression
# A)
x <- c(0,1,2,3,4,5,6,7,8,9,10)
y <- c(3,5,2,6,4,2,7,4,3,3,4)
res.lm <- lm(y ~ x)
summary(res.lm)
residuals(res.lm)

plot(x,y,type='l')
lines(x,predict(res.lm))


# B)
# Global Temperature Deviation from 1856-1997
globtemp <-  ts(scan("globtemp.dat"), start=1856)
plot(globtemp)

gtemp <- window(globtemp, start=1900)           # use years 1990 to 1997
fit = lm(gtemp~time(gtemp), na.action=NULL)    # regress gtemp on time
#-- note: na.action=NULL is used to retain time series attributes - ?lm for info

summary(fit)                # view the results
plot(gtemp, type="o", ylab="Global Temperature Deviation")   #  plot the series
abline(fit,col='red')                 # add regression line to the plot

#####################################################################################
# AUTOCORRELATION

AT<- read.csv('AT.monthly.txt',header = FALSE)
recife <- ts(AT,start=1953,frequency=12)
plot(recife,ylab='Temperature [C]',xlab='Year',main='Recife, Brazil Temperature data')

acf(recife,lag.max=40,main='Autocorrelation for Recife data',ylim=c(-1,1))
# the acf function for default gives(plot) and x-axis in terms of
# the frequency (in this case 12) of the TS object Recife

acf(ts(recife,freq=1),lag.max=40,main='Autocorrelation for Recife data',ylim=c(-1,1))
# we labelled the function for lag 12 months as 1 year.
# Re-stationg the frequency as 1 allows a plot of the acf as we said lag.max=40

# the acf shows the seasonal variation with high positives autocorrelations at lags 12, 24...
# remove the seasonality:
# calculate the mean monthly AirTemperature and substract it from the data
recife.month.mean <- tapply(recife, cycle(recife), mean)
#remove
recife.noseason<- recife-rep(recife.month.mean,9)
plot(recife.noseason,ylab='No-Seasonalised Temp [C]')
acf(ts(recife.noseason,freq=1),lag.max=40,main='Autocorrelation for Non-Seasonalised \n Recife data')



#########################################################################
# ARMA

# A)
data(AirPassengers)
plot(AirPassengers,ylab='(in thousands)',main="Num. of passangers")
# the figure suggests that there is a trend and a seosanlity

# first we will do log as probably the seasonality is multiplicative
AirPass.log<- log(AirPassengers)
plot(AirPass.log,ylab='(in log(thousands))',main="Num. of passangers")

# little function to select "best ARMA"
best.order<-c(0,0,0)
best.aic<- Inf
for (i in 0:2) {
  print(i)
  for (j in 0:2) {
    print(j)
      fit.aic<-AIC(arima(AirPass.log, order=c(i,0,j)))
      if (fit.aic < best.aic) {
        best.order <- c(i,0,j)
        best.arma <- arima(AirPass.log, order=best.order)
        best.aic <- fit.aic
      }
  }
}

best.arma

# B)
# Luteinizing Hormone in Blood Samples
# data()
data(lh)
# fit an AR(1)
lh.ar1 <- ar(lh, aic = F, order.max = 1)
lh.ar1$aic
# cummulative periodogram
cpgram(lh.ar1$resid, main = 'AR(1) fit to lh')

# fit up to AR(9)
lh.ar <- ar(lh, order.max = 9)
lh.ar$aic
# cumulative periodogram
cpgram(lh.ar$resid, main = "AR(3) fit to lh")

# plot data and fitted AR(3)
  plot(lh,ylim=c(0.6,4.9))
  lines(seq(lh), lh.ar$resid+lh, col="red")




