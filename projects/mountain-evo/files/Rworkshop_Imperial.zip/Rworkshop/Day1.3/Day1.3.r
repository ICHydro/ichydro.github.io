
########################################################
## Basic Visualisation                                ##
## --------------------                               ##    
## R workshop 28 September 2015                       ##
## Imperial College London                            ##
## Barbara Orellana Bobadilla                         ##
########################################################


### Exercise 1 ########################################

setwd('D:/Barb/R/workshop/Barb/Day1.3/data')


# The following data provides mean wind speed, among other variables, for 13 different stations
load('NLwind.rda')

  # variables included in data frame NLwind.yearly
    colnames(NLwind.yearly) 
  
  # How many diferent Sites are included in NLwind.yearly ?
    sites<- unique(NLwind.yearly$Site)
    length(sites)

# station.data is a data frame that provides information of Site
# name of station related to each Site are in station.data
sitenames <- gsub("_"," ",rownames(station.data))

# A) Select a Site and plot mean annual wind speed 
    s<- 2
    s.index<- which(NLwind.yearly$Site == s)
    
    plot(NLwind.yearly$Year[s.index],NLwind.yearly$Mean.wind[s.index],
         type='o',xlab='years',ylab='m/s',col='blue',cex=0.5,
         main=sitenames[s],
         ylim=c(0,round(max(NLwind.yearly$Mean.wind)+1)))

# B) Scatter plot of mean annul wind speed between two stations
    w<- 10
    w.index <- which(NLwind.yearly$Site == w)
    maxvalue <- round(max(NLwind.yearly$Mean.wind)+1)
    print(maxvalue)


plot(NLwind.yearly$Mean.wind[w.index],NLwind.yearly$Mean.wind[s.index],
     main='Mean wind speed [m/s]',col='red',
     ylab=sitenames[w],xlab=sitenames[s],xlim=c(0,maxvalue),ylim=c(0,maxvalue),
     pch=16,cex=0.8)
points(c(0,maxvalue),c(0,maxvalue),type='l',lty=2)
        
# C) plotting Mean annual wind speed time series, with legend
plot(NLwind.yearly$Year[s.index],NLwind.yearly$Mean.wind[s.index],type='o',col="red",
     ylab='[m/s]',xlab='years')
lines(NLwind.yearly$Year[w.index],NLwind.yearly$Mean.wind[w.index],type='o',lty=2,pch=8,
       col="blue")
legend('topright', c(sitenames[s],sitenames[w]),
       lty=c(1,2),pch=c(1,8),       
       lwd=c(1,1),bty='n',
       col=c("red","blue"),
       ncol=1) 

# D) legend outside the area

# par sets or adjusts plotting parameters.
# default values of margin 
par("mar")

# mar - A numeric vector of length 4, which sets the margin sizes in the following order:    (bottom, left, top, and right). The default is c(5.1, 4.1, 4.1, 2.1).
# par("fig") describes/sets the location of a figure region as a proportion of the "drawing region" , which is usually the entire device, for single figure plots. It takes a length-4 vector of the form c(xmin, xmax, ymin, ymax) consisting of numbers (proportions) between 0 and 1.
par("fig")

par(fig=c(0,0.9,0.3,0.9), new=TRUE)
plot(NLwind.yearly$Year[s.index],NLwind.yearly$Mean.wind[s.index],type='o',col="red",
     ylab='[m/s]',xlab='years')
lines(NLwind.yearly$Year[w.index],NLwind.yearly$Mean.wind[w.index],type='o',lty=2,pch=8,
      col="blue")

par(fig=c(0,0.9,0,0.25),new=TRUE)
plot(NLwind.yearly$Year[s.index],NLwind.yearly$Mean.wind[s.index],
     ylab='[m/s]',xlab='years',type='n',axes=FALSE,ann=FALSE)
legend('topright', c(sitenames[s],sitenames[w]),
       lty=c(1,2),pch=c(1,8),       
       lwd=c(1,1),bty='n',
       col=c("red","blue"),
       ncol=1) 


par(mfrow=c(1,2))
par(mfg=c(1,1))


### Exercise 2  #######################################

# ggplot2 
library(ggplot2)

# A) Annual mean wind speed for all stations 

# original data represent missing values = -1, we will change it to NA
NLwind.yearly$Mean.wind[which(NLwind.yearly$Mean.wind==-1)]<- NA

g<- ggplot(NLwind.yearly,aes(x=Year,y=Mean.wind))
g 
g+geom_point()+ 
  geom_line(stat = "summary", fun.y = "mean", colour = "blue", size =2)+
  labs(x='Year',y='[m/s]')


# B) scatter plot

g<- ggplot(NLwind.yearly,aes(Min.wind, Max.wind))

  g+geom_point(aes(colour = Site))+
  ggtitle('Comparison Maximum and Minimum wind speed') + # adds a title
  labs(x='Minimum wind speed',y='Maximum wind speed')
  # You control the title  & axis formatting using the theme() function
  # plot.title refers to the title plot 
  # axis.title refer to both axis titles
  # axis.title.x or axis.title.y refers to x-or-y axis title
ggsave('Max_Min.png')


NLwind.yearly$Site.char <- as.character(NLwind.yearly$Site)

g<- ggplot(NLwind.yearly,aes(x=Min.wind, y=Max.wind))
g+geom_point(aes(colour = Site.char))+
  ggtitle('Comparison Maximum and Minimum wind speed') + # adds a title
  labs(x='Minimum wind speed',y='Maximum wind speed')
  

# C) oxplots of Mean annual wind speed for all stations

bp<- ggplot(NLwind.yearly,aes(Site,Mean.wind,color=Site.char)) +
     geom_boxplot(width = 1,
                 outlier.colour="black", outlier.shape=8,
                 outlier.size=2, notch=TRUE)+
     xlab('Stations')+ ylab('annual mean wind speed [m/s]')+
     ggtitle("Comparison wind speed 1950-2002")

bp
   
  # other potential layers 
   theme_bw() + # white background
   
  
    # change the legend position
    bp+ theme(legend.position="bottom")
    
    bp + theme(legend.position="none") # Remove legend

    # modifying legend title and labels
    bp+ theme(legend.position="bottom") + 
       scale_fill_discrete(name="Sites",breaks=sites,labels=sitenames)
    
    bp + scale_fill_discrete(name="Experimental\nCondition",
                             breaks=c("ctrl", "trt1", "trt2"),
                             labels=c("Control", "Treatment 1", "Treatment 2"))

   # Rotate the box plot add
    bp + coord_flip()




#### Exercise 3 ###################################
# lattice
rm(list=ls(all=TRUE))
library(lattice)

# monthly rainfall from 313 rain gauges
data.rain<- read.csv("INAMHI.csv")


# A) plotting rain gauges
# without grouping
tplot<-xyplot(y~x, data=data.rain,
              main='Rain gauges',
              ylab='latitude',
              xlab='longitude')
print(tplot)

# with grouping based on the annual rainfall as factor
# estimate annual rainfall, this will be the factor
data.rain$annual <- rowSums(data.rain[3:dim(data.rain)[2]])
  plot(data.rain$annual,ylab='mm/year')
  abline(h=2000,col='red') 
summary(data.rain$annual)

data.rain$annual.2000 <- data.rain$annual > 2000

tplot<-xyplot(y~x, data=data.rain,
                groups = annual.2000,
                col=c('blue','red'))
print(tplot)
tplot2<-update(tplot,main='Rain gauges',xlab='longitude',ylab='latitude')
print(tplot2)


# adding a legend
tplot3<-update(tplot2, 
               auto.key= list(space='bottom',
                              points=TRUE,
                              lines=FALSE,
                              text=c('< 2000 mm/yr','>= 2000 mm/yr'),
                              title='Annual rainfall : ',
                              cex.title=1,
                              columns=2))
print(tplot3)


# B) histogram
# we condition on the factor
histogram( ~ jul | annual.2000,data = data.rain,
            xlab = "January monthly rainfall (inches)",
            type = "percent", # by default type = percent
            nint = 20,      # number of histogram bins
            layout=c(1,2))  # if you would like plots horizontally then use c(2,1)    

# plotting monthly rainfall during winter (DJF) conditioning in the same factor as above
nsites<- dim(data.rain)[1]
  
# create a data frame that will contain monthly rainfall on dec, jan and feb in one column
data.DJF <- data.frame( months = c(rep('dec',nsites),rep('jan',nsites),rep('feb',nsites)),
                        rain   = c(data.rain$dec,data.rain$jan,data.rain$feb),
                        annual.2000 = rep(data.rain$annual.2000,3))

histogram( ~ rain | annual.2000,data = data.DJF,
           xlab = "DJF monthly rainfall (inches)",
           type = "count", # by default type = percent
           nint = 20)      # number of histogram bins       
           layout=c(1,2))  # if you would like plots horizontally then use c(2,1)




#### Exercise 4 ###################################
# create a RasterLayer from scratch
rm(list=ls(all=TRUE))
library(raster)

# RasterLayer with the default parameters
x.raster <- raster()
x.raster  # raster description

# create RasterLayer With specific parameters
rr.raster   <- raster(nrows=30, ncols=30, xmn=0, xmx=10,ymn=0,ymx=10)
rr.raster[] <- runif(ncell(rr.raster)) # generate a set of random values for
rr.raster[]      # display file values
plot(rr.raster)  # produces plot with legend
#or
spplot(rr.raster) # no legend by default - notice: aspect = 1


    # Obtaining information on columns and row and cell values
    colFromCell(rr.raster, 40)
    cellFromRowCol(rr.raster,30,1)
    # coordinate location:
    xy <- xyFromCell(rr.raster, 1)
    xy

    # You can assess cell values by using - getValues.
    getValues(rr.raster, row=10)         # values of row 10
    getValues(rr.raster, row=10)[9:16]   # notice use of square brackets

#resolution of the previous Raster
res(rr.raster)

#changing the number of columns
res(rr.raster)  <- 2
res(rr.raster)
ncol(rr.raster) # it decreased from 30 to 5

ncol(rr.raster) <- 15 # this only changes the x-resolution but preserves the number of rows (y-resolution)
res(rr.raster)

# A) 
# let's read a tiff file:

## referencia: Nesbitt, S. W., and A. M. Anders, 2009.
## Very high resolution precipitation climatologies from the
## Tropical Rainfall Measuring Mission precipitation radar.
## Geophys. Res. Lett., 36, L15815,

raster.path <- paste(getwd(),'Ecuador_DJF.tif',sep='/')
raster.DJF  <- raster(raster.path,native=T)
summary(raster.DJF)
spplot(raster.DJF, scales=list(draw = TRUE))  # plots a legend with terrain color palette

# load the other seasonal images. For this use the option to search for files on your current working directory

      raster.MAM <- raster(file.choose()) # Ecuador_MAM.tif
      raster.JJA <- raster(file.choose()) # Ecuador_JJA.tif                  
      raster.SON <- raster(file.choose()) # Ecuador_SON.tif

# Examples of using statistics functions

    cellStats(raster.DJF, 'mean') # calculates the file image mean
                                  # sum, min, max, sd, mean, or 'countNA'
# When using MulipleLayers
# A) Maximumvalue and range for the four layers.
  raster.max  <- max(raster.MAM, raster.JJA, raster.SON,raster.DJF)    # max values of 4 layers
  spplot(raster.max)

  raster.range <- range(raster.MAM, raster.JJA, raster.SON,raster.DJF) # range of 4 layers 
  spplot(raster.range)


# B) or by building RasterStacks with the 4 layers.
  raster.stack     <- stack(raster.MAM, raster.JJA, raster.SON,raster.DJF)
  raster.stack.max <- max(raster.stack)      
  spplot(raster.stack.max, main="max cell value for the 4 layer")

  raster.stack.range <- range(raster.stack)
  spplot(raster.stack.range)

# Reclassify 
spplot(raster.stack)

raster.stack.mean<-  mean(raster.stack) 
val<- round(cellStats(raster.stack.mean,'mean'))

# Reclassify using reclassify function
raster.reclassify<- reclassify(raster(raster.stack,layer=1),c(0,val,NA))
spplot(raster.reclassify,main=paste('MAM rainfall for areas >',val,'[mm/season]',sep=' '))

# Equivalent to reclassify but using the calculator function calc
spplot(calc(raster(raster.stack,layer=1),
            fun=function(x){x[x<val] <- NA;
                            return(x)}) )



