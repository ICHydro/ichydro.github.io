
# https://cran.r-project.org/web/packages/topmodel/topmodel.pdf

# if you dont have TOPMODEL R-Package
install.packages('topmodel')

# TOPMODEL comes with a dataset (list) called huagrahuma that we will used for this modelling example

library(topmodel)
data(huagrahuma)
attach(huagrahuma)

# explore the data
names(huagrahuma) # variables

# after ussing 'attach' you are able to called the variables on the list object huagrahuma directly, for example type:

topidx        ### A 2 column matrix with respectively the topographic index classes and values

parameters
length(parameters)

### qs0   Initial subsurface flow per unit area [m]
### lnTe  log of the areal average of T0 [m2/h]
### m     Model parameter controlling the rate of decline of transmissivity in the soil profile, see Beven, 1984
### Sr0   Initial root zone storage deficit [m]
### Srmax Maximum root zone storage deficit [m]
### td    Unsaturated zone time delay per unit storage deficit [h/m
### vch   channel flow outside the catchment [m/h] (currently not used)
### vr    channel flow inside catchment [m/h]
### K0    Surface hydraulic conductivity (m/h)
### CD    capillary drive, see Morel-Seytoux and Khanji (1974)
### dt    The timestep (hours)


rain         # [m per time step]
length(rain) # data points
plot(rain, type="h")

### A)
# relationship between rainfall and flow:
plot(rain,Qobs)
plot(cumsum(rain),col='blue')
# Qobs has NA values
plot(cumsum(rain[!is.na(Qobs)]),col='blue',ylab='Cummulative mm/dt')
points(cumsum(Qobs[!is.na(Qobs)]),col='red')



### B)
# model simulations:
Qsim <- topmodel(parameters, topidx, delay, rain, ET0)

# simulated flow
plot(Qsim, type="l", col="red")
points(Qobs,cex=0.3)


### C)

## Change parameter values

parameters["m"] <- runif(1, min = 0, max = 0.1)
parameters["m"]

## run topmdel with new parmater value
Qsim <- topmodel(parameters, topidx, delay, rain, ET0)

# TOPMODEL provides a NSE function
NSeff(Qobs, Qsim)

## Que resultado obtiene? Le parece bien?
## Verificar con un plot:

plot(Qobs, type='p',pch=16)
points(Qsim,type='l',col='red')

## prepare parameter sampling space

qs0   <- runif(100, min = 0.0001, max = 0.00025)
lnTe  <- runif(100, min = -2, max = 3)
m     <- runif(100, min = 0, max = 0.1)
Sr0   <- runif(100, min = 0, max = 0.2)
Srmax <- runif(100, min = 0, max = 0.1)
td    <- runif(100, min = 0, max = 3)
vch   <- runif(100, min = 100, max = 2500)
vr    <- runif(100, min = 100, max = 2500)
k0    <- runif(100, min = 0, max = 10)
CD    <- runif(100, min = 0, max = 5)
dt    <- 0.25   # dt=6hrs

parameters <- cbind(qs0,lnTe,m,Sr0,Srmax,td,vch,vr,k0,CD,dt)

nsim<- 100
Qsim<- matrix(NA,nrow=length(rain),ncol=nsim)
for(i in 1:nsim) # curly bracket
  Qsim[,i] <- topmodel(parameter[i,],topidx,delay,rain,ET0,Qobs)
  # close curly bracket

NS <- topmodel(parameters, topidx, delay, rain, ET0)
max(NS)

plot(m, NS, ylim=c(0,1))
